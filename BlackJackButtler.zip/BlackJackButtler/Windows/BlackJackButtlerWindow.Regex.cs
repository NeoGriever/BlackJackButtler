using System.Numerics;
using Dalamud.Bindings.ImGui;

namespace BlackJackButtler.Windows;

public partial class BlackJackButtlerWindow
{
    private void DrawRegexPage()
    {
        ImGui.TextUnformatted("Regular Expressions");
        ImGui.Separator();

        ImGui.TextUnformatted("Standard Algorithms");
        var allow = _config.AllowEditingStandardRegex;
        if (ImGui.Checkbox("Allow editing standard regular expressions", ref allow))
        {
            if (allow && !_config.AllowEditingStandardRegex)
            {
                _showRegexWarningPopup = true;
                ImGui.OpenPopup("bjb.regex.warning");
            }
            else if (!allow && _config.AllowEditingStandardRegex)
            {
                _config.AllowEditingStandardRegex = false;
                _save();
            }
        }

        DrawRegexWarningPopup();

        var standardPattern = @"(\d+)\s*$";
        ImGui.BeginDisabled(!_config.AllowEditingStandardRegex);
        ImGui.InputText("Dice value pattern", ref standardPattern, 128, ImGuiInputTextFlags.ReadOnly);
        ImGui.EndDisabled();

        ImGui.BulletText("1 → 11 | 2–9 → 2–9 | 10–13 → 10");
        ImGui.Separator();

        if (ImGui.Button("+ Add Regex Entry")) { _config.UserRegexes.Add(new BlackJackButtler.Regex.UserRegexEntry()); _save(); }

        for (var i = 0; i < _config.UserRegexes.Count; i++)
        {
            var e = _config.UserRegexes[i];
            ImGui.PushID(i);
            if (ImGui.CollapsingHeader(string.IsNullOrWhiteSpace(e.Name) ? $"Entry {i + 1}" : e.Name))
            {
                if (ImGui.Checkbox("Enabled", ref e.Enabled)) _save();
                var name = e.Name ?? "";
                if (ImGui.InputText("Name", ref name, 64)) { e.Name = name; _save(); }
                var pat = e.Pattern ?? "";
                if (ImGui.InputTextMultiline("Pattern", ref pat, 1024, new Vector2(-1, 60))) { e.Pattern = pat; _save(); }

                if (ImGui.GetIO().KeyCtrl && ImGui.Button("Delete")) { _config.UserRegexes.RemoveAt(i); _save(); ImGui.PopID(); break; }
            }
            ImGui.PopID();
        }
    }

    private void DrawRegexWarningPopup()
    {
        if (ImGui.BeginPopupModal("bjb.regex.warning", ref _showRegexWarningPopup, ImGuiWindowFlags.AlwaysAutoResize))
        {
            ImGui.TextWrapped("Editing standard algorithms is for advanced users.");
            if (ImGui.Button("I understand")) { _config.AllowEditingStandardRegex = true; _save(); ImGui.CloseCurrentPopup(); }
            ImGui.SameLine();
            if (ImGui.Button("Cancel")) ImGui.CloseCurrentPopup();
            ImGui.EndPopup();
        }
    }
}
