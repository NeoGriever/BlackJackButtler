using System;

namespace BlackJackButtler.Regex;

public enum RegexEntryMode
{
    SetVariable,
    Reaction
}

[Serializable]
public sealed class UserRegexEntry
{
    // Geändert von { get; set; } zu einfachen Feldern:
    public bool Enabled = true;
    public RegexEntryMode Mode = RegexEntryMode.SetVariable;
    public string Name = "card";
    public string Pattern = "";
    public bool CaseSensitive = false;
}
